 var card1 = [];
 var combos = 0;
// fonction pour cliquer sur les cartes, pour verifier si on a trouver une pair ou non en utilisant des condtions if

 function onCardClicked(e) {
     const target = e.currentTarget;
     console.log(target.className.split(" "));
     target.className = target.className
         .replace('colour-hidden', '')
         .trim();

     card1.push(e.target);
// verifie quil y a 2 cartes quon a cliquer dessus
     if (card1.length === 2) {
// verifie si les deux cartes sont la meme couleur en verifiant la couleur dans la classname en utilisant une split pour verifier le 2ieme mot qui indentifie la coloueur
         if (card1[0].className.split(" ")[1] === card1[1].className.split(" ")[1]) {
// si les deux couleurs sont la meme on ajoute +1 au combos
             combos++;
            //  mets un timeout avant que les cartes devient noir lorsquon trouve une pair
             setTimeout(() => {

                 console.log(card1);
                 card1[0].className += (" match-found");
                 card1[1].className += (" match-found");
                //  vide le array pour quon peut choisir 2 nouvelles cartes
                 card1 = [];

                //  verfie si combos est agele a 8 por voir si tu as gagner

                 if (combos == 8) {
                    //  sort element pour annoncer que tu a gagner par utilisant le class .gagne
                      document.getElementById("win").style.display="block";
                 }
             }, 200);

// le else pour quand les cartes sont pas la meme couleur et retourne la meme couleur quavant avec le meme timeout
         } else {
             setTimeout(() => {
                 card1[0].className += (" colour-hidden");
                 card1[1].className += (" colour-hidden");
                 console.log("not a match");
                 card1 = [];
             }, 200);
         }

     }



 }